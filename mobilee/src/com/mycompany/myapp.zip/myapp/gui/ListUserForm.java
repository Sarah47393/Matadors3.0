package com.mycompany.myapp.gui;

import com.codename1.components.SpanLabel;
import com.codename1.ui.FontImage;
import com.codename1.ui.Form;
import com.mycompany.myapp.services.ServiceUser;
import java.util.ArrayList;
import com.mycompany.myapp.entities.User;

/**
 *
 * @author bhk
 */
public class ListUserForm extends Form {

    public ListUserForm(Form previous) {
        setTitle("List Users");

        SpanLabel sp = new SpanLabel();
        //sp.setText(ServiceUser.getInstance().getAllUsers().toString);
         ArrayList<User> list;
        list = new ArrayList<>();
        list = ServiceUser.getInstance().getAllUsers();
         for ( User ev : list) {
             
             
             
              SpanLabel spl = new SpanLabel("nom: " + "  " + ev.getNom());
                SpanLabel spl2 = new SpanLabel("prenom: " + "  " + ev.getPrenom());
                SpanLabel sp7 = new SpanLabel("cin: " + "  " + ev.getCin());
                SpanLabel sp8 = new SpanLabel("role: " + "  " + ev.getRole());
                SpanLabel sp6 = new SpanLabel("access: " + "  " + ev.getAccess());
                SpanLabel sp4 = new SpanLabel("date: " + "  " + ev.getDatenaissance());
                SpanLabel sp5 = new SpanLabel("image: " + "  " + ev.getImage());
                SpanLabel sp2 = new SpanLabel("password: " + "  " + ev.getPassword());
      
          addAll(spl,spl2,sp7,sp8,sp6,sp4,sp5,sp2);
        
        }
        getToolbar().addMaterialCommandToLeftBar("", FontImage.MATERIAL_ARROW_BACK, e -> previous.showBack());
    }

}
