package com.codename1.ext.filechooser;


/**
 * 
 *  @author shannah
 */
public interface FileChooserNative extends com.codename1.system.NativeInterface {

	public boolean showNativeChooser(String accept, boolean multi);
}
